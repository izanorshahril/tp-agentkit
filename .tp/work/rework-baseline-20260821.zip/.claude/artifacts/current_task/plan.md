# TP-AgentKit Minimal Rework Plan

## Outcome

Replace the script-heavy, `.claude`-branded framework with a small `.tp` framework that discovers each test program dynamically, routes agents to model-invoked skills, writes task-specific harnesses only when needed, verifies through explicit stop criteria, and promotes reusable lessons into living skills or knowledge.

Privacy handling: redact or omit user, person, network, email, host, and account identifiers from maintained examples and evidence.

## Baseline

- current framework: 67 Markdown files, 71 Python files, 28 skill folders, 3 always-on protocol files
- Git metadata: absent; Git cannot provide rollback
- user direction: no fixed TP layout, no bootstrap protocol, no retained tool integration, minimal Markdown, remove most saved scripts, `.tp` branding, dynamic workflows, temporary task context, and evidence-backed learning

## Target Surface

- `AGENTS.md`: compact stable contract and pointer layer
- `README.md`: short user onboarding and example requests
- `.tp/skills/INDEX.md`: model-routing descriptions only
- focused auto-routed skills, each with one `SKILL.md` and embedded adaptable snippets where useful:
  - `map-test-program`
  - `pressure-test-plan`
  - `backup-work`
  - `update-revision`
  - `update-limits`
  - `update-spec`
  - `change-test-flow`
  - `add-test`
  - `improve-test-setup`
  - `analyze-test-evidence`
  - `verify-test-program`
  - `show-work`
  - `learn-from-work`
- `.tp/knowledge/INDEX.md`: living-knowledge router; new topic files appear only after verified reuse justifies them
- `.tp/work/context.md`: temporary privacy preference, environment capabilities, constraints, active goal, and resume checkpoint; verify drift-prone facts before reuse

No permanent implementation scripts, task bootstrap, fixed `testprogram/` or `references/` placement, registries duplicating file contents, task-history archive, or command presets will ship in the initial surface.

## Migration

1. Create a recoverable ZIP baseline containing `AGENTS.md`, `README.md`, `rework.txt`, and `.claude/`.
2. Build `.tp` beside `.claude`; keep pointers cache-stable and bodies progressively disclosed.
3. Rewrite `AGENTS.md` and `README.md` for the new dynamic loop: orient -> map -> pressure-test/plan -> back up -> execute with a task harness -> verify/fix -> show work -> learn.
4. Validate every skill trigger, pointer, example, safety bound, and completion criterion.
5. Remove `.claude/` only after the new surface passes validation; retain the ZIP under `.tp/work/` for rollback.

## Safety And Authorization

- Read-only analysis and reversible task scaffolding proceed autonomously.
- A material TP mutation requires a confirmed target, recoverable baseline, explicit plan, and user approval unless the same request already granted that exact authority.
- Destructive or release-facing operations require fresh verification and explicit remaining-risk disclosure.
- On-the-fly scripts stay task-local until repeated successful use proves that a permanent helper is cheaper and safer than re-derivation.

## Verification Criteria

- no live `.claude` path remains
- no bundled `.py`, `.bat`, `.ps1`, or task preset remains in `.tp`
- every indexed skill path exists and every skill has valid `name` and discriminating `description` frontmatter
- all skill descriptions are automatic trigger pointers rather than user-only commands
- no fixed TP folder layout or bootstrap sequence is prescribed
- backup, plan approval, variant/baseline choice, unit/scale checks, structure preservation, and partial-validation reporting remain explicit where risk requires them
- privacy-sensitive literal scan is clean for maintained new text
- Markdown and relative-link checks pass
- representative scenario reviews route correctly for revision, limits, spec, flow, new test, setup, evidence analysis, backup, verification, reporting, and learning
- the final file and line-count delta demonstrates material simplification

## Pending Grill Decision

Because Git is absent, confirm whether the rollback ZIP may be retained at `.tp/work/rework-baseline-20260820.zip` while the live `.claude/` tree is removed.
