---
name: map-test-program
description: Map an unfamiliar test program's active launch, flows, dependencies, variants, and evidence into a task-sized navigation surface. Use before modifying or explaining a TP when the owning paths or runtime reachability are not already proven.
---

# Map the program

Build a **task map**, not a repository dump. Read `.tp/knowledge/test-programs.md` when the file family looks like an ATE program covered there.

## Map

1. Start from the user-named program and evidence. Use `rg --files` and targeted searches; expand only when a missing edge blocks the task.
2. Identify platform and launch clues from content, extensions, configuration, and referenced paths. Treat familiar names as hints until a file proves the edge.
3. Trace the active path: launch -> top plan -> subplan or flow -> test/limit/bin definition -> implementation -> datalog or runtime evidence.
4. Separate source presence, active reachability, and observed runtime coverage.
5. Record only the relevant nodes, key symbols or identifiers, owning files, variant, source of truth, and unresolved decisions.

Use a compact work note when the map must survive a long task:

```markdown
# Task map
- Target and variant:
- Active launch:
- Authority:
- Edges: file/symbol -> consumer
- Invariants:
- Evidence available:
- Unknowns that change execution:
```

Store it under `.tp/work/` and refresh it when source evidence contradicts the cache.

## Boundaries

- Avoid loading entire large files when headers, references, symbols, and local neighborhoods answer the question.
- Follow generated or copied names back to active callers before treating them as authoritative.
- Do not declare a program, flow, or test absent until recursive key-file discovery and reference following both fail.

## Complete when

Every proposed edit or conclusion is connected to its active consumer, the correct variant and authority are named, and every remaining unknown is either non-decision-relevant or surfaced to the user.
